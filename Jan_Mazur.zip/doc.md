# JanuszeX DB API

Program uruchamiamy poleceniem `./main.py`.
Plik ten jednak musi mieć uprawnienia executable `chmod +x main.py`.

[Model konceptualny](conceptual_model.md)

